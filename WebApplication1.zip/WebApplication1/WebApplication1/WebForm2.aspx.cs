﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Services;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.Script.Serialization;

namespace WebApplication1
{
    public partial class WebForm2 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }
        [WebMethod]
        public static string GetData()
        {
            List<MapCLass> lst = new List<MapCLass>();
            lst.Add(new MapCLass() { Name = "shre", Latitude = "30.2568", Longitude = "55.2569",Description="Nothing to say", Location = "Delhi", Id = "656" });
            JavaScriptSerializer js = new JavaScriptSerializer();
            return js.Serialize(lst);
        }
        public class MapCLass
        {
            public string Name { get; set; }
            public string Latitude { get; set; }
            public string Longitude { get; set; }
            public string Location { get; set; }
            public string Description { get; set; }
            public string Id { get; set; }
        }
    }
}
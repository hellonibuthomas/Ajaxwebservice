﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Script.Serialization;
using System.Web.Services;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace WebApplication1
{
    public partial class WebForm1 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }
        [WebMethod]
        public string HelloWorld(string extra_search)
        {
            List<MyClass> lst = new List<MyClass>();
            int i = 0;
            while (i < 1)
            {
                lst.Add(new MyClass() { Empid = "1", Name = "hr" });
                lst.Add(new MyClass() { Empid = "2", Name = "hr" });
                lst.Add(new MyClass() { Empid = "3", Name = "hr" });
                i = i + 1;
            }
            var mydata = new DataTable()
            {
                aaData = lst,
                iTotalDisplayRecords = lst.Count,
                iTotalRecords = lst.Count
            };
            JavaScriptSerializer js = new JavaScriptSerializer();
            js.MaxJsonLength = int.MaxValue;
            return js.Serialize(mydata);

        }

        public class DataTable
        {
            public int iTotalRecords { get; set; }
            public int iTotalDisplayRecords { get; set; }
            public List<MyClass> aaData { get; set; }
        }
        public class MyClass
        {
            public string Empid { get; set; }
            public string Name { get; set; }
        }

    }
}

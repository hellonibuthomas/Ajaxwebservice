﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Services;
using System.Web.Script.Serialization;

namespace WebApplication1
{
    /// <summary>
    /// Summary description for WebService
    /// </summary>
    [WebService(Namespace = "http://tempuri.org/")]
    [WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
    [System.ComponentModel.ToolboxItem(false)]
    // To allow this Web Service to be called from script, using ASP.NET AJAX, uncomment the following line. 
    [System.Web.Script.Services.ScriptService]
    public class WebService : System.Web.Services.WebService
    {

        [WebMethod]
        public void HelloWorld()
        {
            List<MyClass> lst = new List<MyClass>();
            int i = 0;
            while (i < 8000)
            {
                lst.Add(new MyClass() { Empid = "1", Name = "hr" });
                lst.Add(new MyClass() { Empid = "2", Name = "Shr" });
                lst.Add(new MyClass() { Empid = "5", Name = "Shr" });
                lst.Add(new MyClass() { Empid = "1", Name = "Shr" });
                lst.Add(new MyClass() { Empid = "1", Name = "Shr" });
                lst.Add(new MyClass() { Empid = "1", Name = "Shr" });
                lst.Add(new MyClass() { Empid = "1", Name = "Shr" });
                lst.Add(new MyClass() { Empid = "1", Name = "hr" });
                lst.Add(new MyClass() { Empid = "2", Name = "Shr" });
                lst.Add(new MyClass() { Empid = "5", Name = "Shr" });
                lst.Add(new MyClass() { Empid = "1", Name = "Shr" });
                lst.Add(new MyClass() { Empid = "1", Name = "Shr" });
                lst.Add(new MyClass() { Empid = "1", Name = "Shr" });
                lst.Add(new MyClass() { Empid = "1", Name = "Shr" });
                lst.Add(new MyClass() { Empid = "1", Name = "hr" });
                lst.Add(new MyClass() { Empid = "2", Name = "Shr" });
                lst.Add(new MyClass() { Empid = "5", Name = "Shr" });
                lst.Add(new MyClass() { Empid = "1", Name = "Shr" });
                lst.Add(new MyClass() { Empid = "1", Name = "Shr" });
                lst.Add(new MyClass() { Empid = "1", Name = "Shr" });
                lst.Add(new MyClass() { Empid = "1", Name = "Shr" });
                lst.Add(new MyClass() { Empid = "1", Name = "hr" });
                lst.Add(new MyClass() { Empid = "2", Name = "Shr" });
                lst.Add(new MyClass() { Empid = "5", Name = "Shr" });
                lst.Add(new MyClass() { Empid = "1", Name = "Shr" });
                lst.Add(new MyClass() { Empid = "1", Name = "Shr" });
                lst.Add(new MyClass() { Empid = "1", Name = "Shr" });
                lst.Add(new MyClass() { Empid = "1", Name = "Shr" });
                lst.Add(new MyClass() { Empid = "1", Name = "hr" });
                lst.Add(new MyClass() { Empid = "2", Name = "Shr" });
                lst.Add(new MyClass() { Empid = "5", Name = "Shr" });
                lst.Add(new MyClass() { Empid = "1", Name = "Shr" });
                lst.Add(new MyClass() { Empid = "1", Name = "Shr" });
                lst.Add(new MyClass() { Empid = "1", Name = "Shr" });
                lst.Add(new MyClass() { Empid = "1", Name = "Shr" });
                lst.Add(new MyClass() { Empid = "1", Name = "hr" });
                lst.Add(new MyClass() { Empid = "2", Name = "Shr" });
                lst.Add(new MyClass() { Empid = "5", Name = "Shr" });
                lst.Add(new MyClass() { Empid = "1", Name = "Shr" });
                lst.Add(new MyClass() { Empid = "1", Name = "Shr" });
                lst.Add(new MyClass() { Empid = "1", Name = "Shr" });
                lst.Add(new MyClass() { Empid = "1", Name = "Shr" });
                lst.Add(new MyClass() { Empid = "1", Name = "hr" });
                lst.Add(new MyClass() { Empid = "2", Name = "Shr" });
                lst.Add(new MyClass() { Empid = "5", Name = "Shr" });
                lst.Add(new MyClass() { Empid = "1", Name = "Shr" });
                lst.Add(new MyClass() { Empid = "1", Name = "Shr" });
                lst.Add(new MyClass() { Empid = "1", Name = "Shr" });
                lst.Add(new MyClass() { Empid = "1", Name = "Shr" });
                lst.Add(new MyClass() { Empid = "1", Name = "hr" });
                lst.Add(new MyClass() { Empid = "2", Name = "Shr" });
                lst.Add(new MyClass() { Empid = "5", Name = "Shr" });
                lst.Add(new MyClass() { Empid = "1", Name = "Shr" });
                lst.Add(new MyClass() { Empid = "1", Name = "Shr" });
                lst.Add(new MyClass() { Empid = "1", Name = "Shr" });
                lst.Add(new MyClass() { Empid = "1", Name = "Shr" });
                i = i + 1;
            }
           var mydata=new DataTable()
           {
           aaData=lst,iTotalDisplayRecords=lst.Count,iTotalRecords=lst.Count
           };
            JavaScriptSerializer js=new JavaScriptSerializer();
            js.MaxJsonLength = int.MaxValue;
          Context.Response.Write(js.Serialize(mydata));
        
     }
           
     }
    public class DataTable
    {
        public int iTotalRecords { get; set; }
        public int iTotalDisplayRecords { get; set; }
        public List<MyClass> aaData { get; set; }
    }
    public class MyClass
    {
        public string Empid { get; set; }
        public string Name { get; set; }
    }
    }
    
